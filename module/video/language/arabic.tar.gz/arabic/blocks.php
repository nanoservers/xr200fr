<?php
define("_MB_VIDEO_ALLCAT","كافة الفروع");
define("_MB_VIDEO_CATTODISPLAY","اختر الفروع التي تم عرضها");
define("_MB_VIDEO_CHARS","طول العنوان");
define("_MB_VIDEO_DISP","العرض");
define("_MB_VIDEO_FILES","شريط الفيديو");
define("_MB_VIDEO_LENGTH","الشخصية");
define("_MB_VIDEO_HEIGHT","ارتفاع الصورة");
define("_MB_VIDEO_WIDTH","عرض الصورة");
define("_MB_VIDEO_VIDTODISPLAY","اختر أشرطة الفيديو التي تم عرضها");
define("_MB_VIDEO_DATE","تاريخ الارسال: ");
define("_MB_VIDEO_HIT","الزيارة: ");
define("_MB_VIDEO_LOGO","عرض الشعار");
define("_MB_VIDEO_DESCRIPTION","عرض الملاحظات");
define("_MB_VIDEO_IMGW","قياسات الصورة");
define("_MB_VIDEO_DESCCHARS","طول التوضيحات");
define("_MB_VIDEO_AUTHOR","المرسل: ");
define("_MB_VIDEO_INFO","عرض معلومات شريط الفيديو");
define("_MB_VIDEO_SORT","نوعية عرض شريط الفيديو");
define("_MB_VIDEO_RANDOM","عرضي");
define("_MB_VIDEO_SELECT","الاختيار");
define("_MB_VIDEO_ID","رقم شريط الفيديو من أجل تسليط الضوء عليه");
?>