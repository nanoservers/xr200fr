<?php
// Non du module
define("_MI_VIDEO_NAME","شريط الفيديو");

// Description du module
define("_MI_VIDEO_DESC","تنظيمات شريط فيديو محترف فيه امكانية الارسال وتغيير التنظيمات والعرض");

// Bloc
define("_MI_VIDEO_BNAME1","أشرطة الفيديو الأخيرة");
define("_MI_VIDEO_BNAMEDSC1","عرض أشرطة الفيديو الأخيرة");
define("_MI_VIDEO_BNAME2","أفضل أشرطة الفيديو");
define("_MI_VIDEO_BNAMEDSC2","عرض أفضل أشرطة الفيديو");
define("_MI_VIDEO_BNAME3","أشرطة فيديو حصلت على أكبر تصويت");
define("_MI_VIDEO_BNAMEDSC3","عرض أشرطة فيديو حصلت على أكبر تصويت");
define("_MI_VIDEO_BNAME4","أشرطة فيديو عرضية");
define("_MI_VIDEO_BNAMEDSC4","عرض أشرطة فيديو عرضية");
define("_MI_VIDEO_BNAME5","أشرطة فيديو مختارة");
define("_MI_VIDEO_BNAMEDSC5","");
define("_MI_VIDEO_BNAME6","عرض شريط فيدي");
define("_MI_VIDEO_BNAMEDSC6","");
define("_MI_VIDEO_BNAME7","أشرطة فيديو أخيرة مجدولة");
define("_MI_VIDEO_BNAMEDSC7","عرض أشرطة الفيديو الأخيرة المجدولة");
define("_MI_VIDEO_BNAME8","الكشاف");
define("_MI_VIDEO_BNAMEDSC8","الكشاف");

// Sous menu
define("_MI_VIDEO_SMNAME1","الارسال");
define("_MI_VIDEO_SMNAME2","البحث");
define("_MI_VIDEO_SMNAME3","الشبكة");

// Menu administration
define("_MI_VIDEO_ADMENU1", "الصفحة الرئيسية");
define("_MI_VIDEO_ADMENU2","الفروع");
define("_MI_VIDEO_ADMENU3"," أشرطة الفيديو");
define("_MI_VIDEO_ADMENU4","عطل");
define("_MI_VIDEO_ADMENU5","تم تنقيحه");
define("_MI_VIDEO_ADMENU6","حقل اضافي");
define("_MI_VIDEO_ADMENU7","حول");
define("_MI_VIDEO_ADMENU8", "الحصول");
define("_MI_VIDEO_ADMENU9", "تحسين");
define("_MI_VIDEO_ADMENU10", "ادخال المعلومات");

// Pr�f�rences
define('_MI_VIDEO_SERIAL', 'سریال نرم افزار');
define('_MI_VIDEO_SERIALDSC', '');
define('_MI_VIDEO_POPULAR', 'تعداد بازدید های که باعث میشوند یک ویدیو جز محبوب ها قرار بگیرد');
define('_MI_VIDEO_POPULARDSC', '');
define('_MI_VIDEO_NEWDLS', "تعداد بازدید های که باعث میشوند یک ویدیو جز محبوب ها قرار بگیرد");
define('_MI_VIDEO_NEWDLSDSC', '');
define('_MI_VIDEO_PERPAGE', 'تعداد ویدیو هایی که در هر صفحه نمایش داده میشوند');
define('_MI_VIDEO_PERPAGEDSC', '');
define('_MI_VIDEO_SUBCATPARENT', 'تعداد زیر شاخه هایی که در شاخه اصلی نمایش داده میشود');
define('_MI_VIDEO_SUBCATPARENTDSC', '');
define('_MI_VIDEO_NBBL', 'تعداد ویدیو هاییکه در بخش خلاصه نمایش داده میشود?');
define('_MI_VIDEO_NBBLDSC', '');
define('_MI_VIDEO_LONGBL', 'طول عنوان خلاصه ');
define('_MI_VIDEO_LONGBLDSC', '');
define("_MI_VIDEO_ANONUPLOADS","اجازه به کاربر مهمان برای بارگذاری ویدیو؟");
define('_MI_VIDEO_USETELLAFRIEND', 'استفاده از ماژول Tellafriend برای معرفی ویدیو به دوستان؟');
define('_MI_VIDEO_USETELLAFRIENDDSC', 'برای استفاده از این گزینه باید ماژول Tellafriend را نصب کنید');
define('_MI_VIDEO_AUTOAPPROVE',"تایید خودکار ویدیو های ارسال شده بدون نیاز به تایید مدیر؟");
define('_MI_VIDEO_AUTOAPPROVEDSC', '');
define('_MI_VIDEO_SHOTWIDTH', "ارتفاع تصویر");
define('_MI_VIDEO_SHOTWIDTHDSC', '');
define('_MI_VIDEO_CHECKHOST', "عدم اجازه لینک ویدیو مستقیم؟ (leeching)");
define('_MI_VIDEO_CHECKHOSTDSC', "");
define('_MI_VIDEO_REFERERS', "این سایت ها بدون واسطه به ویدیو شما لینک میدهند هر کدام را با | از بقیه جدا کنید");
define('_MI_VIDEO_REFERERSDSC', '');
define('_MI_VIDEO_MIMETYPE',"authorized mime types ");
define('_MI_VIDEO_MIMETYPE_DSC',"Enter the authorized mime types separated by a |");
define('_MI_VIDEO_MAXUPLOAD_SIZE',"بیشترین اندازه ویدیو برای بارگذاری");
define('_MI_VIDEO_MAXUPLOAD_SIZEDSC',"");
define("_MI_VIDEO_FORM_OPTIONS","ویرایشگر ها");
define("_MI_VIDEO_FORM_OPTIONSDSC","");
define('_MI_VIDEO_TOPORDER',"چگونگی ترتیب نمایش اطلاعات در صفحه اصلی؟");
define('_MI_VIDEO_TOPORDER1',"تاریخ ارسال (نزولی)");
define('_MI_VIDEO_TOPORDER2',"تاریخ ارسال (صعودی)");
define('_MI_VIDEO_TOPORDER3',"بازدید (نزولی)");
define('_MI_VIDEO_TOPORDER4',"بازدید (صعودی)");
define('_MI_VIDEO_TOPORDER5',"رای (نزولی)");
define('_MI_VIDEO_TOPORDER6',"رای (صعودی)");
define('_MI_VIDEO_TOPORDER7',"عنوان (نزولی)");
define('_MI_VIDEO_TOPORDER8',"عنوان (صعودی)");
define('_MI_VIDEO_TOPORDERDSC','');
define('_MI_VIDEO_SEARCHORDER',"چگونگی ترتیب نمایش اطلاعات در فهرست ویدیو ها؟");
define('_MI_VIDEO_SEARCHORDERDSC','');
define('_MI_VIDEO_PERPAGELISTE', 'تعداد دریافت هایی که در فهرست ویدیو ها نمایش داده میشد');
define('_MI_VIDEO_PERPAGELISTEDSC', '');
define('_MI_VIDEO_AUTO_SUMMARY',"خلاصه خودکار؟");
define('_MI_VIDEO_AUTO_SUMMARYDSC',"");
define('_MI_VIDEO_SHOW_UPDATED',"نمایش تصاویر 'به روز شده' و 'جدید'  ؟");
define('_MI_VIDEO_SHOW_UPDATEDDSC',"");
define('_MI_VIDEO_PERMISSIONDOWNLOAD',"نوع دسترسی را برای 'دسترسی دانلود'  انتخاب کنید");
define('_MI_VIDEO_PERMISSIONDOWNLOADDSC',"");
define('_MI_VIDEO_PERMISSIONDOWNLOAD1',"دسترسی با شاخه");
define('_MI_VIDEO_PERMISSIONDOWNLOAD2',"دسترسی با ویدیو");
define('_MI_VIDEO_USEPAYPAL',"استفاده از دکمه 'کمک' به وسیله Paypal");
define('_MI_VIDEO_USEPAYPALDSC',"");
define('_MI_VIDEO_CURRENCYPAYPAL',"اهدای کمک");
define('_MI_VIDEO_CURRENCYPAYPALDSC',"");
define('_MI_VIDEO_IMAGEPAYPAL',"تصویر برای دکمه کمک به پروژه");
define('_MI_VIDEO_IMAGEPAYPALDSC',"لطفا آدرس تصویر را وارد کنید");

//new 1.1
define('_MI_VIDEO_PLATEFORM',"بستر های نرم افزاری");
define('_MI_VIDEO_PLATEFORM_DSC',"بستر های نرم افزاری مورد تایید را وارد کنید و آنها رابا | از هم جدا کنید");
define('_MI_VIDEO_PERPAGEADMIN', 'تعداد موارد در هر صفحه در بخش مدیریت');
define('_MI_VIDEO_PERPAGEADMINDSC', '');
define('_MI_VIDEO_DOWNLOAD_NAME', 'تغیر نام ویدیو بارگذاری شده؟');
define('_MI_VIDEO_DOWNLOAD_NAMEDSC', 'اگر این گزینه روی خیر باشد و شما ویدیوی را که هم اکنون نام آن موجود است بارگذاری کنید , سرور به طور خودکار ویدیو جدید را جایگزین ویدیو قبلی میکند');
define('_MI_VIDEO_DOWNLOAD_PREFIX', 'پیشوند برای نام ویدیو های بارگذاری شده');
define('_MI_VIDEO_DOWNLOAD_PREFIXDSC', 'فقط در صورتی کار میکند که امکان تغییر نام ویدیو بعد از بارگذاری را روی بله قرار داده باشید');
define('_MI_VIDEO_USETAG', 'استفاده از ماژول TAG برای تولید تگ ها');
define('_MI_VIDEO_USETAGDSC', 'برای استفاده از این گزینه باید ماژول TAG را نصب کرده باشید');

define('_MI_VIDEO_FFMPEG', 'مسیر اجرای ffmpeg');
define('_MI_VIDEO_LOGO', 'لوگو ویدیو');
define('_MI_VIDEO_FLV_PATH', 'مسیر ذخیره ویدیوهای FLV');
define('_MI_VIDEO_FLV_WIDTH', 'عرض ویدیو FLV');
define('_MI_VIDEO_FLV_HEIGHT', 'ارتفاع ویدیو FLV');
define('_MI_VIDEO_PLAYER_WIDTH', 'عرض پلیر');
define('_MI_VIDEO_PLAYER_HEIGHT', 'ارتفاع پلیر');
define('_MI_VIDEO_THUMB_PATH', 'مسیر ذخیره تصاویر ویدئو');
define('_MI_VIDEO_THUMB_WIDTH', 'عرض تصویر');
define('_MI_VIDEO_THUMB_HEIGHT', 'ارتفاع تصویر');
define('_MI_VIDEO_NBCOLUM', 'تعداد ستون ها');
define('_MI_VIDEO_SOCIAL', 'شبکه های اجتماعی');
define('_MI_VIDEO_BOOKMARK', 'بوک مارک');
define('_MI_VIDEO_WHICHFILE', 'دریافت فایل تبدیل شده');
define('_MI_VIDEO_WHICHFILE_DSC', 'اگر بر روی نه باشد فایل اصلی دریافت میشود');
define('_MI_VIDEO_PERPAGERSS', 'تعداد خوراک');
define('_MI_VIDEO_PERPAGERSSDSC', 'تعداد خوراک در صفحه');
define('_MI_VIDEO_TIMECACHERSS', 'زمان کش');
define('_MI_VIDEO_TIMECACHERSSDSC', 'زمان کش خوراک');
define('_MI_VIDEO_LOGORSS', 'لوگو خوراک');

//new 1.2
define('_MI_VIDEO_ACODEC', 'Audio Codec');
define('_MI_VIDEO_ACODECDSC', 'Use copy or libfaac');
define('_MI_VIDEO_VCODEC', 'Video Codec');
define('_MI_VIDEO_VCODECDSC', 'Use copy or libx264');
define('_MI_VIDEO_ASAMPLERATE', 'Audio Samplerate');
define('_MI_VIDEO_ASAMPLERATEDSC', '');
define('_MI_VIDEO_ABITRATE', 'Audio Bitrate');
define('_MI_VIDEO_ABITRATEDSC', '');
define('_MI_VIDEO_VRATE', 'Video Rate');
define('_MI_VIDEO_VRATEDSC', '');
define('_MI_VIDEO_VMAXRATE', 'Video max rate');
define('_MI_VIDEO_VMAXRATEDSC', '');
define('_MI_VIDEO_VLOGO', 'Convert Logo');
define('_MI_VIDEO_VLOGODSC', '');
define('_MI_VIDEO_OVERLAYH', 'Logo Overlay Height');
define('_MI_VIDEO_OVERLAYHDSC', '');
define('_MI_VIDEO_OVERLAYW', 'Logo Overlay Width');
define('_MI_VIDEO_OVERLAYWDSC', '');
define('_MI_VIDEO_CONVERTTYPE', 'نوع رشته تبدیل');
define('_MI_VIDEO_CONVERTTYPEDSC', '');
define('_MI_VIDEO_TYPE_SHORT', 'کوتاه');
define('_MI_VIDEO_TYPE_NORMAL', 'نرمال');
define('_MI_VIDEO_TYPE_LOGO', 'لوگو');
define('_MI_VIDEO_TYPE_LOCAL', 'لوکال');

define('_MI_VIDEO_PREFERENCE_BREAK_SERIAL', 'سریال');
define('_MI_VIDEO_PREFERENCE_BREAK_VIDEO', 'ویدیو');
define('_MI_VIDEO_PREFERENCE_BREAK_DIS', 'نمایش');
define('_MI_VIDEO_PREFERENCE_BREAK_RSS', 'خوراک');
define('_MI_VIDEO_PREFERENCE_BREAK_COMNOTI', 'نظر و آگاهی رسانی');

// Notifications
define('_MI_VIDEO_GLOBAL_NOTIFY', 'العامة');
define('_MI_VIDEO_GLOBAL_NOTIFYDSC', ' تعميم لاستلام شريط الفيديو');
define('_MI_VIDEO_CATEGORY_NOTIFY', 'الفرع');
define('_MI_VIDEO_CATEGORY_NOTIFYDSC', "يتم استخدام تنظيمات المعلومات لشريط الفيديو هذا.");
define('_MI_VIDEO_FILE_NOTIFY', 'شريط الفيديو');
define('_MI_VIDEO_FILE_NOTIFYDSC', "تنظیمات اطلاع رسانی که برای همین ویدیو به کار میرود.");
define('_MI_VIDEO_GLOBAL_NEWCATEGORY_NOTIFY', 'فرع جديد');
define('_MI_VIDEO_GLOBAL_NEWCATEGORY_NOTIFYCAP', ' أخبرني عن ايجاد كل فرع جديد.');
define('_MI_VIDEO_GLOBAL_NEWCATEGORY_NOTIFYDSC', "ارسل لي كل فرع جديد يتم ايجاده");
define('_MI_VIDEO_GLOBAL_NEWCATEGORY_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE}  المعلومات الآلية حول فرع جديد');
define('_MI_VIDEO_GLOBAL_FILEMODIFY_NOTIFY', ' المعلومات الآلية حول فرع جديد');
define('_MI_VIDEO_GLOBAL_FILEMODIFY_NOTIFYCAP', 'هاخبرني عن كل طلب حول تصليح عطل في شريط فيديو.');
define('_MI_VIDEO_GLOBAL_FILEMODIFY_NOTIFYDSC', " ارسل لي كل طلب حول تصليح عطل في شريط الفيديو.");
define('_MI_VIDEO_GLOBAL_FILEMODIFY_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE}الاعلام الآلي عن طلب في اصلاح شريط فيديو');
define('_MI_VIDEO_GLOBAL_FILEBROKEN_NOTIFY', 'Broken File Submitted');
define('_MI_VIDEO_GLOBAL_FILEBROKEN_NOTIFYCAP', ' أخبرني عن كل  تقرير يأتي من الموقع حول ارسال شريط فيديو عاطل.');
define('_MI_VIDEO_GLOBAL_FILEBROKEN_NOTIFYDSC', 'ارسل لي كل  تقرير يأتي من الموقع حول ارسال شريط فيديو عاطل.');
define('_MI_VIDEO_GLOBAL_FILEBROKEN_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE} الاعلام الآلي حول ارسال شريط فيديو من خارج الموقع ‌');
define('_MI_VIDEO_GLOBAL_FILESUBMIT_NOTIFY', ' تم ارسال شريط الفيديو');
define('_MI_VIDEO_GLOBAL_FILESUBMIT_NOTIFYCAP', " أخبرني عن كل شريط فيديو تم ارساله (awaiting approval).");
define('_MI_VIDEO_GLOBAL_FILESUBMIT_NOTIFYDSC', " أخبرني عن كل شريط فيديو تم ارساله (awaiting approval).");
define('_MI_VIDEO_GLOBAL_FILESUBMIT_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE}  الاعلام الآلي حول شريط الفيديو الذي تم ارساله');
define('_MI_VIDEO_GLOBAL_NEWFILE_NOTIFY', 'شريط فيديو');
define('_MI_VIDEO_GLOBAL_NEWFILE_NOTIFYCAP', "أخبرني عن كل شريط فيديو تم ارساله.");
define('_MI_VIDEO_GLOBAL_NEWFILE_NOTIFYDSC', 'ارسل لي كل شريط فيديو تم ارساله.');
define('_MI_VIDEO_GLOBAL_NEWFILE_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE} الاعلام الآلي عن شريط فيديو جديد');
define('_MI_VIDEO_CATEGORY_FILESUBMIT_NOTIFY', 'تم تسجيل شريط الفيديو');
define('_MI_VIDEO_CATEGORY_FILESUBMIT_NOTIFYCAP', "أخبرني عن كل شريط فيديو تم تسجيله.");
define('_MI_VIDEO_CATEGORY_FILESUBMIT_NOTIFYDSC', " أرسل لي كل شريط فيديو تم تسجيله.");
define('_MI_VIDEO_CATEGORY_FILESUBMIT_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE}  اطلاع رسانی خودکار:ویدیو ثبت شده در شاخه');
define('_MI_VIDEO_CATEGORY_NEWFILE_NOTIFY', 'شريط فيديو جدي');
define('_MI_VIDEO_CATEGORY_NEWFILE_NOTIFYCAP', "اخبرني عن كل شريط فيديو الذي يوضع في هذا الفرع.");
define('_MI_VIDEO_CATEGORY_NEWFILE_NOTIFYDSC', " ارسل لي كل شريط فيديو الذي يوضع في هذا الفرع.");
define('_MI_VIDEO_CATEGORY_NEWFILE_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE} الاعلام الآلي عن شريط فيديو جديد في الفرع');
define('_MI_VIDEO_FILE_APPROVE_NOTIFY', 'شريط فيديو مصادق عليه');
define('_MI_VIDEO_FILE_APPROVE_NOTIFYCAP', 'أخبرني عن كل شريط فيديو تمت المصادقة عليه.');
define('_MI_VIDEO_FILE_APPROVE_NOTIFYDSC', 'أرسل لي كل شريط فيديو تمت المصادقة عليه.');
define('_MI_VIDEO_FILE_APPROVE_NOTIFYSBJ', '[{X_SITENAME}] {X_MODULE}  الاعلام الآلي عن شريط فيديو تمت المصادقة عليه');

// version 1.25
define('_MI_VIDEO_SHOW_EXTRA', 'معلومات اضافية');
define('_MI_VIDEO_SHOW_EXTRA_DSC', 'عرض حقل معلومات اضافية لشريط الفيدي');
define('_MI_VIDEO_RELATED', 'أشرطة فيديو مشابهة');
define('_MI_VIDEO_RELATED_DSC', ' امكانية اختيار أشرطة الفيديو المشابهة في الاطار');
?>